/**
 * SynDaver Wifi Module
 * Copyright (C) 2020  SynDaver Labs, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

let apiPrefix = "http://192.168.1.92"
let currentDir = "/"

class UI {
    static clearEntries() {
        document.getElementById("files").innerHTML = ""
    }

    static addButton(li, text, callback) {
       if(!callback) return
       const btn = document.createElement("button")
       btn.innerHTML = text
       btn.addEventListener("click", callback)
       li.appendChild(btn) 
    }

    static addEntry(name, attr) {
        const a = document.createElement("a")
        const li = document.createElement("li")

        a.innerText = name
        if(attr.type == "dir") a.innerText += "/"
        if(attr.type == "up")  a.innerText = ".."
        if(attr.onClick)       a.addEventListener("click", attr.onClick)

        li.appendChild(a)
        UI.addButton(li, "&#x1f5b6;", attr.onPrint)
        UI.addButton(li, "&#x1f5d1;", attr.onDelete)
        document.getElementById("files").append(li)
    }

    static setStatus(str, className = "success") {
        const el = document.getElementById("status")
        el.innerHTML = str
        if(className) el.classList.add(className)
    }

    static setError(str) {
        UI.setStatus(str, 'error')
    }

    static dropStart() {
        document.getElementById("dropzone").classList.add("dropping")
    }

    static dropEnd() {
        document.getElementById("dropzone").classList.remove("dropping")
    }
}

class Main {
    static changeDirectory(dir) {
        if(dir == "..") {
            currentDir = currentDir.substring(0, currentDir.lastIndexOf("/"));
        } else {
            currentDir = dir;
        }
        if(currentDir == "") {
            currentDir = "/";
        }
        Main.refreshFileList();
    }

    static async refreshFileList() {
        const response = await fetch(apiPrefix + "/api/list?path=" + currentDir);
        if (!response.ok) return;

        const listing = await response.json();

        UI.clearEntries();
        if(currentDir != "/") {
            UI.addEntry("..", {type: "up", onClick: () => Main.changeDirectory("..")});
        }
        listing.forEach(entry => {
            let isDir = entry.type == "dir";
            let isGCode = entry.name.endsWith(".gco") || entry.name.endsWith(".gcode");
            let attr = {type: entry.type};
            let name = entry.name.substring(entry.name.lastIndexOf("/")+1);
            if(isDir) attr.onClick = () => Main.changeDirectory(entry.name);
            attr.onDelete = () => Main.deleteFile(entry.name);
            if(isGCode) attr.onPrint  = () => Main.printFile(entry.name);
            UI.addEntry(name, attr);
        });
    }

    static async printFile(path) {
        const response = await fetch(apiPrefix + "/api/print?path=" + path);
        if (!response.ok) return;
    }

    static async deleteFile(path) {
        const response = await fetch(apiPrefix + path, {method: "DELETE"});
        Main.refreshFileList();
    }

    static getFilePath(filename) {
        const separator = currentDir.endsWith("/") ? "" : "/";
        return apiPrefix + currentDir + separator + filename;
    }

    static async postFile(file) {
        try {
            const data = new FormData();
            data.append("file", file, file.name);

            const response = await fetch(
                Main.getFilePath(file.name),
                {method: "POST", body: data}
            );
        } catch (e) {
            console.error('Error:', e);
        } finally {
            Main.refreshFileList();
        }
    }

    static onDragOver(e) {
        e.preventDefault();
    }

    static onDragEnter(e) {
        e.preventDefault();
        UI.dropStart();
    }

    static onDragLeave(e) {
        e.preventDefault();
        UI.dropEnd();
    }

    static onDrop(e) {
        UI.dropEnd();
        e.preventDefault();
        Main.postFile(e.dataTransfer.files[0]);
    }

    static onFileChange() {
        Main.postFile(this.files[0]);
    }

    static onLoad() {
        Main.refreshFileList();
        
        const drop = document.getElementById('dropzone');
        const file = document.getElementById('file');

        file.addEventListener('change',    Main.onFileChange);
        drop.addEventListener('dragover',  Main.onDragOver); 
        drop.addEventListener('dragenter', Main.onDragEnter);
        drop.addEventListener('dragleave', Main.onDragLeave);
        drop.addEventListener('drop',      Main.onDrop);
    }

    static async uninstall() {
        try {
            let registration = await navigator.serviceWorker.getRegistration();
            if (!registration) return;
            await registration.unregister()
            UI.setStatus('The application has been uninstalled');
            setTimeout(() => location.reload(), 500);
        }
        catch(error) {
            UI.setError('Uninstallation failed');
            console.log(error);
        }
    }
}